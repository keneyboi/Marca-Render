from django.apps import AppConfig


class RegisterConfig(AppConfig):
    name = 'apps.register'
